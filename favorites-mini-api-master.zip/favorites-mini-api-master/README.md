# favorites-mini-api

```bash
npm i

# for running in regular mode using just node.
npm run start
# or for running in watch mode using nodemon.
npm run watch
```
